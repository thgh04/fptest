module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'bca99543-b033-4ab5-895f-46a524ceb259'
};